package com.example.azkar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
